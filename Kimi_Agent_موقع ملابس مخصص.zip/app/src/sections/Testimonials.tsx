import { useState, useEffect } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    id: 1,
    name: 'أحمد محمد',
    role: 'مصور فوتوغرافي',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.05.jpeg',
    rating: 5,
    text: 'تجربة رائعة! جودة الطباعة ممتازة والموديلات احترافية جداً. الصورة طلعت أحلى مما توقعت. أنصح الجميع بتجربته.',
    product: 'هودي كلاسيك',
  },
  {
    id: 2,
    name: 'خالد العلي',
    role: 'مدير شركة',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.06.jpeg',
    rating: 5,
    text: 'طلبت للفريق كله وكانت النتيجة مذهلة. التحويل الاحترافي للصور والطباعة عالية الجودة. شكراً على الخدمة الممتازة.',
    product: 'تيشيرت بريميوم',
  },
  {
    id: 3,
    name: 'سعد عبدالله',
    role: 'مصمم جرافيك',
    image: '/mnt/okcomputer/upload/InShot_20260210_000023533.png',
    rating: 5,
    text: 'كمصمم، أقدر جداً الاهتمام بالتفاصيل والجودة. الموديلات فنية وإبداعية. التوصيل كان سريع والتغليف ممتاز.',
    product: 'هودي بريميوم',
  },
  {
    id: 4,
    name: 'فهد الرشيد',
    role: 'رياضي',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.05.jpeg',
    rating: 5,
    text: 'القماش ممتاز والطباعة ثابتة حتى بعد عدة غسلات. التصميم فخم ويلفت النظر. سأطلب مرة أخرى بالتأكيد.',
    product: 'تيشيرت كلاسيك',
  },
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const nextSlide = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark">
        <div className="absolute inset-0 bg-gradient-to-b from-dark via-dark-light/20 to-dark" />
        
        {/* Decorative Elements */}
        <div className="absolute top-20 left-20 w-64 h-64 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-gold/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 mb-6">
            <MessageCircle className="w-4 h-4 text-gold" />
            <span className="text-sm font-medium text-gold">آراء العملاء</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-4">
            ماذا يقول <span className="text-gradient">عملاؤنا</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            تجارب حقيقية من عملائنا الكرام الذين جربوا خدماتنا
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="relative">
          {/* Main Testimonial */}
          <div className="relative max-w-4xl mx-auto">
            <div className="relative bg-dark-light rounded-3xl p-8 md:p-12 border border-white/10 overflow-hidden">
              {/* Quote Icon */}
              <div className="absolute top-8 right-8 w-16 h-16 rounded-2xl bg-gold/10 flex items-center justify-center">
                <Quote className="w-8 h-8 text-gold" />
              </div>

              {/* Content */}
              <div className="relative">
                {testimonials.map((testimonial, index) => (
                  <div
                    key={testimonial.id}
                    className={`transition-all duration-500 ${
                      index === currentIndex
                        ? 'opacity-100 translate-x-0'
                        : 'opacity-0 absolute inset-0 translate-x-8'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row items-center gap-8">
                      {/* Avatar */}
                      <div className="relative flex-shrink-0">
                        <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl overflow-hidden border-2 border-gold/30">
                          <img
                            src={testimonial.image}
                            alt={testimonial.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-xl bg-gold flex items-center justify-center">
                          <Star className="w-5 h-5 text-dark fill-dark" />
                        </div>
                      </div>

                      {/* Text Content */}
                      <div className="flex-1 text-center md:text-right">
                        {/* Rating */}
                        <div className="flex items-center justify-center md:justify-start gap-1 mb-4">
                          {[...Array(testimonial.rating)].map((_, i) => (
                            <Star key={i} className="w-5 h-5 text-gold fill-gold" />
                          ))}
                        </div>

                        {/* Quote */}
                        <p className="text-lg md:text-xl text-white mb-6 leading-relaxed">
                          "{testimonial.text}"
                        </p>

                        {/* Author Info */}
                        <div className="flex flex-col md:flex-row items-center gap-4">
                          <div>
                            <h4 className="font-bold text-white">{testimonial.name}</h4>
                            <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                          </div>
                          <div className="hidden md:block w-px h-8 bg-white/20" />
                          <div className="px-4 py-2 rounded-xl bg-gold/10 border border-gold/30">
                            <span className="text-sm text-gold">{testimonial.product}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <Button
                onClick={prevSlide}
                variant="outline"
                size="icon"
                className="w-12 h-12 rounded-full border-white/20 hover:bg-gold hover:text-dark hover:border-gold transition-all"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>

              {/* Dots */}
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setIsAutoPlaying(false);
                      setCurrentIndex(index);
                    }}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentIndex
                        ? 'bg-gold w-8'
                        : 'bg-white/30 hover:bg-white/50'
                    }`}
                  />
                ))}
              </div>

              <Button
                onClick={nextSlide}
                variant="outline"
                size="icon"
                className="w-12 h-12 rounded-full border-white/20 hover:bg-gold hover:text-dark hover:border-gold transition-all"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Side Testimonials (Desktop) */}
          <div className="hidden xl:grid grid-cols-2 gap-6 mt-12">
            {testimonials
              .filter((_, i) => i !== currentIndex)
              .slice(0, 2)
              .map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="bg-dark-light/50 rounded-2xl p-6 border border-white/5 hover:border-gold/30 transition-all cursor-pointer"
                  onClick={() => {
                    setIsAutoPlaying(false);
                    setCurrentIndex(testimonials.findIndex((t) => t.id === testimonial.id));
                  }}
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-bold text-white text-sm">{testimonial.name}</h4>
                      <div className="flex gap-0.5">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 text-gold fill-gold" />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm mt-3 line-clamp-2">
                    "{testimonial.text}"
                  </p>
                </div>
              ))}
          </div>
        </div>
      </div>
    </section>
  );
}
