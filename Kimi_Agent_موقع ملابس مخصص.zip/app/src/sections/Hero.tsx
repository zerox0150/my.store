import { useEffect, useRef } from 'react';
import { ArrowDown, Sparkles, Shirt, Camera, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const x = (clientX / innerWidth - 0.5) * 20;
      const y = (clientY / innerHeight - 0.5) * 20;
      
      const elements = heroRef.current.querySelectorAll('.parallax');
      elements.forEach((el, i) => {
        const factor = (i + 1) * 0.5;
        (el as HTMLElement).style.transform = `translate(${x * factor}px, ${y * factor}px)`;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-dark">
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `linear-gradient(rgba(255,193,7,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,193,7,0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }}
        />
        
        {/* Floating Orbs */}
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl parallax" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gold/5 rounded-full blur-3xl parallax" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold/5 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-right space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 animate-fade-in">
              <Sparkles className="w-4 h-4 text-gold" />
              <span className="text-sm font-medium text-gold">طباعة مخصصة بأعلى جودة</span>
            </div>

            {/* Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight animate-slide-up">
              <span className="text-white">حوّل صورتك إلى</span>
              <br />
              <span className="text-gradient">تحفة فنية على الملابس</span>
            </h1>

            {/* Description */}
            <p className="text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              ارفع صورتك الشخصية، اختر الموديل الذي يعجبك، وسنقوم بتحويل صورتك إلى تصميم 
              احترافي مطبوع على الهوديز والتيشيرتات بأعلى جودة.
            </p>

            {/* Features */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
              {[
                { icon: Camera, text: 'رفع صورة سهل' },
                { icon: Palette, text: 'موديلات متنوعة' },
                { icon: Shirt, text: 'جودة طباعة عالية' },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10"
                >
                  <feature.icon className="w-4 h-4 text-gold" />
                  <span className="text-sm text-muted-foreground">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-slide-up" style={{ animationDelay: '0.4s' }}>
              <Button
                onClick={() => scrollToSection('#products')}
                size="lg"
                className="bg-gold hover:bg-gold-dark text-dark font-bold px-8 py-6 rounded-2xl text-lg transition-all duration-300 hover:shadow-gold-lg"
              >
                <Shirt className="w-5 h-5 ml-2" />
                تصفح المنتجات
              </Button>
              <Button
                onClick={() => scrollToSection('#how-it-works')}
                size="lg"
                variant="outline"
                className="border-white/20 hover:bg-white/5 text-white font-bold px-8 py-6 rounded-2xl text-lg"
              >
                كيفية الطلب
              </Button>
            </div>
          </div>

          {/* Right Content - Product Showcase */}
          <div className="relative animate-scale-in">
            {/* Main Product Image */}
            <div className="relative">
              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gold/20 rounded-3xl blur-3xl transform scale-110" />
              
              {/* Product Card */}
              <div className="relative bg-gradient-to-br from-dark-light to-dark rounded-3xl p-6 border border-white/10 shadow-2xl">
                <img
                  src="/mnt/okcomputer/upload/Screenshot 2026-02-06 231246.png"
                  alt="منتجاتنا"
                  className="w-full h-auto rounded-2xl"
                />
                
                {/* Floating Badge */}
                <div className="absolute -top-4 -right-4 bg-gold text-dark font-bold px-4 py-2 rounded-xl shadow-gold">
                  جديد
                </div>
                
                {/* Price Tag */}
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-dark-light border border-gold/30 px-6 py-3 rounded-2xl flex items-center gap-3">
                  <span className="text-muted-foreground text-sm">ابتداء من</span>
                  <span className="text-gold font-black text-2xl">199 درهم</span>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-8 -left-8 w-20 h-20 bg-gold/20 rounded-2xl backdrop-blur-xl border border-gold/30 flex items-center justify-center animate-float">
              <Camera className="w-8 h-8 text-gold" />
            </div>
            <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-gold/20 rounded-xl backdrop-blur-xl border border-gold/30 flex items-center justify-center animate-float" style={{ animationDelay: '1s' }}>
              <Palette className="w-6 h-6 text-gold" />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={() => scrollToSection('#products')}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground hover:text-gold transition-colors"
      >
        <span className="text-sm">اسحب للأسفل</span>
        <ArrowDown className="w-5 h-5 animate-bounce" />
      </button>
    </section>
  );
}
