import { useState, useRef, useEffect } from 'react';
import { Upload, Palette, Shirt, Truck, CheckCircle, Camera, Sparkles } from 'lucide-react';

const steps = [
  {
    id: 1,
    title: 'ارفع صورتك',
    description: 'قم برفع صورتك الشخصية عالية الجودة من خلال نموذج الطلب',
    icon: Upload,
    color: 'from-blue-500 to-blue-600',
  },
  {
    id: 2,
    title: 'اختر الموديل',
    description: 'اختار الموديل والتأثير الذي يعجبك من مجموعتنا المتنوعة',
    icon: Palette,
    color: 'from-purple-500 to-purple-600',
  },
  {
    id: 3,
    title: 'نحول صورتك',
    description: 'نقوم بتحويل صورتك لتتناسب مع الموديل المختار بشكل احترافي',
    icon: Sparkles,
    color: 'from-gold to-amber-600',
  },
  {
    id: 4,
    title: 'اختر المنتج',
    description: 'اختار الهودي أو التيشيرت واللون والمقاس المناسب لك',
    icon: Shirt,
    color: 'from-green-500 to-green-600',
  },
  {
    id: 5,
    title: 'نطبع ونوصل',
    description: 'نقوم بطباعة التصميم بأعلى جودة وتوصيله لباب بيتك',
    icon: Truck,
    color: 'from-red-500 to-red-600',
  },
];

export default function HowItWorks() {
  const [activeStep, setActiveStep] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const interval = setInterval(() => {
              setActiveStep((prev) => (prev + 1) % steps.length);
            }, 2000);
            return () => clearInterval(interval);
          }
        });
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="how-it-works" ref={sectionRef} className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark">
        <div className="absolute inset-0 bg-gradient-to-b from-dark via-dark-light/30 to-dark" />
        
        {/* Animated Grid */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,193,7,0.3) 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 mb-6">
            <CheckCircle className="w-4 h-4 text-gold" />
            <span className="text-sm font-medium text-gold">كيفية الطلب</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-4">
            خطوات <span className="text-gradient">بسيطة</span> للحصول على منتجك
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            عملية سهلة ومبسطة لتحويل صورتك إلى منتج فريد ومميز
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-white/10 -translate-y-1/2">
            <div 
              className="h-full bg-gradient-to-r from-gold via-gold to-gold/50 transition-all duration-1000"
              style={{ width: `${((activeStep + 1) / steps.length) * 100}%` }}
            />
          </div>

          {/* Steps Grid */}
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
            {steps.map((step, index) => (
              <div
                key={step.id}
                className={`relative group cursor-pointer transition-all duration-500 ${
                  index === activeStep ? 'scale-105' : 'opacity-70 hover:opacity-100'
                }`}
                onClick={() => setActiveStep(index)}
              >
                {/* Step Card */}
                <div className={`
                  relative bg-dark-light rounded-3xl p-6 border transition-all duration-500
                  ${index === activeStep 
                    ? 'border-gold shadow-gold' 
                    : 'border-white/10 hover:border-white/30'
                  }
                `}>
                  {/* Step Number */}
                  <div className={`
                    absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full 
                    flex items-center justify-center font-bold text-sm
                    transition-all duration-500
                    ${index <= activeStep 
                      ? 'bg-gold text-dark' 
                      : 'bg-white/10 text-muted-foreground'
                    }
                  `}>
                    {index < activeStep ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      step.id
                    )}
                  </div>

                  {/* Icon */}
                  <div className={`
                    w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${step.color}
                    flex items-center justify-center transition-all duration-500
                    ${index === activeStep ? 'scale-110 shadow-lg' : ''}
                  `}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-bold text-white text-center mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-muted-foreground text-center">
                    {step.description}
                  </p>
                </div>

                {/* Arrow for desktop */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                    <div className={`
                      w-6 h-6 rounded-full flex items-center justify-center
                      transition-all duration-500
                      ${index < activeStep ? 'bg-gold text-dark' : 'bg-white/10 text-muted-foreground'}
                    `}>
                      <span className="text-xs">→</span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Preview Section */}
        <div className="mt-16">
          <div className="relative bg-dark-light rounded-3xl p-8 border border-white/10 overflow-hidden">
            {/* Background Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
            
            <div className="relative grid md:grid-cols-2 gap-8 items-center">
              {/* Left - Preview Image */}
              <div className="relative">
                <div className="aspect-square rounded-2xl overflow-hidden bg-dark border border-white/10">
                  {activeStep === 0 && (
                    <div className="w-full h-full flex flex-col items-center justify-center p-8">
                      <div className="w-32 h-32 rounded-2xl bg-white/5 border-2 border-dashed border-gold/50 flex items-center justify-center mb-4">
                        <Camera className="w-12 h-12 text-gold/50" />
                      </div>
                      <p className="text-muted-foreground text-center">ارفع صورتك هنا</p>
                    </div>
                  )}
                  {activeStep === 1 && (
                    <img 
                      src="/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.05.jpeg" 
                      alt="موديل" 
                      className="w-full h-full object-cover"
                    />
                  )}
                  {activeStep === 2 && (
                    <img 
                      src="/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.06.jpeg" 
                      alt="صورة محولة" 
                      className="w-full h-full object-cover"
                    />
                  )}
                  {activeStep === 3 && (
                    <img 
                      src="/mnt/okcomputer/upload/Screenshot 2026-02-06 231246.png" 
                      alt="منتج" 
                      className="w-full h-full object-cover"
                    />
                  )}
                  {activeStep === 4 && (
                    <div className="w-full h-full flex flex-col items-center justify-center p-8">
                      <Truck className="w-20 h-20 text-gold mb-4" />
                      <p className="text-gold font-bold text-xl">جاري التوصيل</p>
                    </div>
                  )}
                </div>

                {/* Step Indicator */}
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {steps.map((_, i) => (
                    <div
                      key={i}
                      className={`w-2 h-2 rounded-full transition-all duration-300 ${
                        i === activeStep ? 'bg-gold w-6' : 'bg-white/30'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Right - Description */}
              <div className="text-center md:text-right">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 mb-4">
                  <span className="text-gold font-bold">الخطوة {activeStep + 1}</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
                  {steps[activeStep].title}
                </h3>
                <p className="text-muted-foreground text-lg mb-6">
                  {steps[activeStep].description}
                </p>
                <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                  {steps[activeStep].icon && (
                    <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10">
                      {(() => {
                        const IconComponent = steps[activeStep].icon;
                        return <IconComponent className="w-5 h-5 text-gold" />;
                      })()}
                      <span className="text-sm text-muted-foreground">سهل وسريع</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gold/10 border border-gold/30">
                    <CheckCircle className="w-5 h-5 text-gold" />
                    <span className="text-sm text-gold">جودة مضمونة</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
