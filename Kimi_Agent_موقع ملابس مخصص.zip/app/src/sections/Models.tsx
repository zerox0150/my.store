import { useState } from 'react';
import { Palette, Check, ArrowLeft, Sparkles, Droplets, Crown, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const models = [
  {
    id: 1,
    name: 'موديل المطر',
    description: 'تأثير درامي مع قطرات المطر لإضفاء جو من الغموض والجاذبية',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.05.jpeg',
    icon: Droplets,
    features: ['تأثير المطر الواقعي', 'إضاءة درامية', 'ألوان معدنية'],
    style: 'درامي / غموض',
    price: 50,
  },
  {
    id: 2,
    name: 'موديل كلاسيكي',
    description: 'أناقة كلاسيكية مع لمسة عربية أصيلة وتفاصيل تقليدية',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.06.jpeg',
    icon: Crown,
    features: ['زي عربي تقليدي', 'خلفية داكنة', 'تفاصيل ذهبية'],
    style: 'كلاسيكي / عربي',
    price: 60,
  },
  {
    id: 3,
    name: 'موديل فاخر',
    description: 'مظهر فاخر وأنيق مع سيارة رياضية للإبراز الفاخر',
    image: '/mnt/okcomputer/upload/InShot_20260210_000023533.png',
    icon: Car,
    features: ['بدلة رسمية', 'سيارة رياضية', 'تأثير ذهبي'],
    style: 'فاخر / رياضي',
    price: 70,
  },
  {
    id: 4,
    name: 'موديل عصري',
    description: 'تصميم عصري شبابي مع ألوان زاهية وتأثيرات إبداعية',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.05.jpeg',
    icon: Sparkles,
    features: ['ألوان زاهية', 'تأثيرات نيون', 'خلفية حضرية'],
    style: 'عصري / شبابي',
    price: 45,
  },
  {
    id: 5,
    name: 'موديل فني',
    description: 'تحويل صورتك إلى لوحة فنية بأسلوب رسم إبداعي',
    image: '/mnt/okcomputer/upload/WhatsApp Image 2026-02-08 at 14.22.06.jpeg',
    icon: Palette,
    features: ['أسلوب رسم', 'تفاصيل فنية', 'ألوان مائية'],
    style: 'فني / إبداعي',
    price: 55,
  },
  {
    id: 6,
    name: 'موديل سينمائي',
    description: 'تأثير سينمائي احترافي مع إضاءة سينمائية مذهلة',
    image: '/mnt/okcomputer/upload/InShot_20260210_000023533.png',
    icon: Sparkles,
    features: ['إضاءة سينمائية', 'تباين عالي', 'ألوان سينمائية'],
    style: 'سينمائي / احترافي',
    price: 65,
  },
];

export default function Models() {
  const [selectedModel, setSelectedModel] = useState<typeof models[0] | null>(null);

  return (
    <section id="models" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 mb-6">
            <Palette className="w-4 h-4 text-gold" />
            <span className="text-sm font-medium text-gold">الموديلات</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-4">
            اختر <span className="text-gradient">الموديل</span> المناسب
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            مجموعة متنوعة من الموديلات والتأثيرات الاحترافية لتحويل صورتك إلى تحفة فنية
          </p>
        </div>

        {/* Models Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {models.map((model, index) => (
            <div
              key={model.id}
              className="group relative bg-dark-light rounded-3xl overflow-hidden border border-white/10 hover:border-gold/50 transition-all duration-500 hover-lift"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Model Image */}
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={model.image}
                  alt={model.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-light via-dark/50 to-transparent" />
                
                {/* Style Badge */}
                <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-dark/80 backdrop-blur-sm border border-white/20">
                  <span className="text-xs text-gold">{model.style}</span>
                </div>

                {/* Icon */}
                <div className="absolute top-4 left-4 w-10 h-10 rounded-xl bg-gold/20 backdrop-blur-sm border border-gold/30 flex items-center justify-center">
                  <model.icon className="w-5 h-5 text-gold" />
                </div>

                {/* Content Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-gold transition-colors">
                    {model.name}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                    {model.description}
                  </p>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {model.features.slice(0, 2).map((feature, i) => (
                      <div key={i} className="flex items-center gap-1 px-2 py-1 rounded-lg bg-white/10">
                        <Check className="w-3 h-3 text-gold" />
                        <span className="text-xs text-white/80">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* Price & CTA */}
                  <div className="flex items-center justify-between">
                    <div className="text-gold font-bold">
                      +{model.price} ر.س
                    </div>
                    <Button
                      onClick={() => setSelectedModel(model)}
                      size="sm"
                      className="bg-gold hover:bg-gold-dark text-dark font-bold"
                    >
                      التفاصيل
                      <ArrowLeft className="w-4 h-4 mr-2" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Model Details Dialog */}
      <Dialog open={!!selectedModel} onOpenChange={() => setSelectedModel(null)}>
        <DialogContent className="bg-dark-light border-white/10 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gradient flex items-center gap-3">
              {selectedModel && <selectedModel.icon className="w-6 h-6" />}
              {selectedModel?.name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedModel && (
            <div className="space-y-6">
              {/* Model Image */}
              <div className="aspect-video rounded-2xl overflow-hidden">
                <img
                  src={selectedModel.image}
                  alt={selectedModel.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Description */}
              <p className="text-muted-foreground">{selectedModel.description}</p>

              {/* Style */}
              <div>
                <h4 className="font-bold text-white mb-2">الأسلوب:</h4>
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gold/10 border border-gold/30">
                  <span className="text-gold">{selectedModel.style}</span>
                </div>
              </div>

              {/* Features */}
              <div>
                <h4 className="font-bold text-white mb-3">المميزات:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedModel.features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10">
                      <Check className="w-4 h-4 text-gold" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price & CTA */}
              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <div>
                  <span className="text-muted-foreground text-sm">السعر الإضافي</span>
                  <div className="text-3xl font-black text-gold">+{selectedModel.price} ر.س</div>
                </div>
                <Button
                  onClick={() => {
                    setSelectedModel(null);
                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-gold hover:bg-gold-dark text-dark font-bold px-8 py-6 rounded-xl"
                >
                  اختر هذا الموديل
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
