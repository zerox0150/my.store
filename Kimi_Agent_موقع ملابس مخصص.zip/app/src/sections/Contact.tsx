import { useState, useRef } from 'react';
import { 
  Send, 
  Phone, 
  Mail, 
  MapPin, 
  Upload, 
  CheckCircle, 
  Shirt,
  Palette,
  User,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const products = [
  { id: 'hoodie-classic', name: 'هودي كلاسيك - 249 ر.س' },
  { id: 'tshirt-premium', name: 'تيشيرت بريميوم - 149 ر.س' },
  { id: 'hoodie-premium', name: 'هودي بريميوم - 299 ر.س' },
  { id: 'tshirt-classic', name: 'تيشيرت كلاسيك - 129 ر.س' },
];

const models = [
  { id: 'rain', name: 'موديل المطر - +50 ر.س' },
  { id: 'classic', name: 'موديل كلاسيكي - +60 ر.س' },
  { id: 'luxury', name: 'موديل فاخر - +70 ر.س' },
  { id: 'modern', name: 'موديل عصري - +45 ر.س' },
  { id: 'artistic', name: 'موديل فني - +55 ر.س' },
  { id: 'cinematic', name: 'موديل سينمائي - +65 ر.س' },
];

const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const colors = ['أسود', 'أبيض', 'رمادي', 'أحمر', 'أزرق', 'أخضر'];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    product: '',
    model: '',
    size: '',
    color: '',
    notes: '',
  });
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setShowSuccess(true);
    
    // Reset form
    setFormData({
      name: '',
      phone: '',
      email: '',
      product: '',
      model: '',
      size: '',
      color: '',
      notes: '',
    });
    setUploadedImage(null);
  };

  const whatsappNumber = '+212770247882';
  const whatsappMessage = `مرحباً، أريد طلب منتج من PrintStyle\nالاسم: ${formData.name}\nالمنتج: ${formData.product}\nالموديل: ${formData.model}`;

  return (
    <section id="contact" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark">
        <div className="absolute inset-0 bg-gradient-to-b from-dark via-dark-light/30 to-dark" />
        
        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 mb-6">
            <Send className="w-4 h-4 text-gold" />
            <span className="text-sm font-medium text-gold">اطلب الآن</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-4">
            ابدأ <span className="text-gradient">طلبك</span> الآن
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            املأ النموذج وسنقوم بالتواصل معك لتأكيد الطلب
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-dark-light rounded-3xl p-6 border border-white/10">
              <h3 className="text-xl font-bold text-white mb-6">معلومات التواصل</h3>
              
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5">
                  <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">الهاتف</p>
                    <p className="text-white font-medium">+966 50 123 4567</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5">
                  <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">البريد الإلكتروني</p>
                    <p className="text-white font-medium">info@printstyle.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5">
                  <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">الموقع</p>
                    <p className="text-white font-medium">الرياض، المملكة العربية السعودية</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Contact */}
            <div className="bg-gradient-to-br from-gold/20 to-gold/5 rounded-3xl p-6 border border-gold/30">
              <h3 className="text-lg font-bold text-white mb-4">تواصل سريع</h3>
              <p className="text-muted-foreground text-sm mb-4">
                هل لديك استفسار؟ تواصل معنا مباشرة عبر الواتساب
              </p>
              <a
                href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-6 rounded-xl">
                  <svg className="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  تواصل عبر الواتساب
                </Button>
              </a>
            </div>
          </div>

          {/* Order Form */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="bg-dark-light rounded-3xl p-6 md:p-8 border border-white/10">
              <h3 className="text-xl font-bold text-white mb-6">نموذج الطلب</h3>
              
              <div className="space-y-6">
                {/* Personal Info */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white flex items-center gap-2">
                      <User className="w-4 h-4 text-gold" />
                      الاسم الكامل *
                    </Label>
                    <Input
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="أدخل اسمك الكامل"
                      className="bg-white/5 border-white/10 text-white placeholder:text-muted-foreground focus:border-gold"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-white flex items-center gap-2">
                      <Phone className="w-4 h-4 text-gold" />
                      رقم الجوال *
                    </Label>
                    <Input
                      required
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="05xxxxxxxx"
                      className="bg-white/5 border-white/10 text-white placeholder:text-muted-foreground focus:border-gold"
                    />
                  </div>
                </div>

                {/* Product Selection */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white flex items-center gap-2">
                      <Shirt className="w-4 h-4 text-gold" />
                      اختر المنتج *
                    </Label>
                    <Select
                      value={formData.product}
                      onValueChange={(value) => setFormData({ ...formData, product: value })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="اختر المنتج" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-light border-white/10">
                        {products.map((product) => (
                          <SelectItem key={product.id} value={product.id} className="text-white">
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-white flex items-center gap-2">
                      <Palette className="w-4 h-4 text-gold" />
                      اختر الموديل *
                    </Label>
                    <Select
                      value={formData.model}
                      onValueChange={(value) => setFormData({ ...formData, model: value })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="اختر الموديل" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-light border-white/10">
                        {models.map((model) => (
                          <SelectItem key={model.id} value={model.id} className="text-white">
                            {model.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Size & Color */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white">المقاس *</Label>
                    <Select
                      value={formData.size}
                      onValueChange={(value) => setFormData({ ...formData, size: value })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="اختر المقاس" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-light border-white/10">
                        {sizes.map((size) => (
                          <SelectItem key={size} value={size} className="text-white">
                            {size}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-white">اللون *</Label>
                    <Select
                      value={formData.color}
                      onValueChange={(value) => setFormData({ ...formData, color: value })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="اختر اللون" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-light border-white/10">
                        {colors.map((color) => (
                          <SelectItem key={color} value={color} className="text-white">
                            {color}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Image Upload */}
                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <Upload className="w-4 h-4 text-gold" />
                    ارفع صورتك *
                  </Label>
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className={`
                      relative border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer
                      transition-all duration-300
                      ${uploadedImage 
                        ? 'border-gold bg-gold/5' 
                        : 'border-white/20 hover:border-gold/50 hover:bg-white/5'
                      }
                    `}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    
                    {uploadedImage ? (
                      <div className="relative">
                        <img
                          src={uploadedImage}
                          alt="Uploaded"
                          className="max-h-48 mx-auto rounded-xl"
                        />
                        <div className="absolute top-2 right-2 w-8 h-8 rounded-full bg-gold flex items-center justify-center">
                          <CheckCircle className="w-5 h-5 text-dark" />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="w-16 h-16 mx-auto rounded-2xl bg-gold/10 flex items-center justify-center">
                          <Upload className="w-8 h-8 text-gold" />
                        </div>
                        <p className="text-white font-medium">اضغط لرفع الصورة</p>
                        <p className="text-sm text-muted-foreground">JPG, PNG حتى 10MB</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-gold" />
                    ملاحظات إضافية
                  </Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="أي ملاحظات خاصة بالطلب..."
                    className="bg-white/5 border-white/10 text-white placeholder:text-muted-foreground focus:border-gold min-h-[100px]"
                  />
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isSubmitting || !uploadedImage}
                  className="w-full bg-gold hover:bg-gold-dark text-dark font-bold py-6 rounded-xl disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-dark/30 border-t-dark rounded-full animate-spin" />
                      جاري الإرسال...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Send className="w-5 h-5" />
                      إرسال الطلب
                    </span>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="bg-dark-light border-white/10 text-white text-center max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gradient">
              تم إرسال طلبك بنجاح!
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-6">
            <div className="w-20 h-20 mx-auto rounded-full bg-gold/20 flex items-center justify-center mb-4">
              <CheckCircle className="w-10 h-10 text-gold" />
            </div>
            <p className="text-muted-foreground mb-4">
              سنتواصل معك قريباً لتأكيد الطلب وتحديد موعد التسليم
            </p>
            <p className="text-sm text-gold">
              رقم الطلب: #{Math.random().toString(36).substr(2, 9).toUpperCase()}
            </p>
          </div>

          <Button
            onClick={() => setShowSuccess(false)}
            className="bg-gold hover:bg-gold-dark text-dark font-bold"
          >
            حسناً
          </Button>
        </DialogContent>
      </Dialog>
    </section>
  );
}
