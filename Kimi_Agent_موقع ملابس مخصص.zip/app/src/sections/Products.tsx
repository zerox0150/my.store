import { useState } from 'react';
import { Shirt, Check, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const products = [
  {
    id: 1,
    name: 'هودي كلاسيك',
    description: 'هودي قطني 100% بجودة عالية، مثالي للطباعة المخصصة',
    price: 249,
    image: '/mnt/okcomputer/upload/Screenshot 2026-02-06 231246.png',
    colors: ['أسود', 'أبيض', 'رمادي', 'أحمر', 'أزرق'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    features: ['قطن 100%', 'طباعة عالية الجودة', 'مقاوم للغسيل'],
  },
  {
    id: 2,
    name: 'تيشيرت بريميوم',
    description: 'تيشيرت قطني ناعم بتصميم عصري يناسب جميع الأذواق',
    price: 149,
    image: '/mnt/okcomputer/upload/Screenshot 2026-02-06 231246.png',
    colors: ['أسود', 'أبيض', 'رمادي', 'أخضر', 'أصفر'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    features: ['قطن مصري', 'نعومة فائقة', 'ألوان ثابتة'],
  },
  {
    id: 3,
    name: 'هودي بريميوم',
    description: 'هودي فاخر ببطانة داخلية ناعمة لراحة فائقة',
    price: 299,
    image: '/mnt/okcomputer/upload/Screenshot 2026-02-06 231246.png',
    colors: ['أسود', 'أبيض', 'كحلي', 'زيتي'],
    sizes: ['M', 'L', 'XL', 'XXL'],
    features: ['بطانة ناعمة', 'جيوب جانبية', 'سحاب معدني'],
  },
  {
    id: 4,
    name: 'تيشيرت كلاسيك',
    description: 'تيشيرت كلاسيكي بقصة مريحة مناسب للاستخدام اليومي',
    price: 129,
    image: '/mnt/okcomputer/upload/Screenshot 2026-02-06 231246.png',
    colors: ['أسود', 'أبيض', 'رمادي', 'أحمر', 'أزرق', 'أخضر'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    features: ['قصة مريحة', 'تنفس ممتاز', 'سعر اقتصادي'],
  },
];

export default function Products() {
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);

  return (
    <section id="products" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dark">
        <div className="absolute inset-0 bg-gradient-to-b from-dark via-dark-light to-dark opacity-50" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 mb-6">
            <Shirt className="w-4 h-4 text-gold" />
            <span className="text-sm font-medium text-gold">منتجاتنا</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-4">
            اختر منتجك <span className="text-gradient">المفضل</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            مجموعة متنوعة من الهوديز والتيشيرتات عالية الجودة، جاهزة لطباعتها بتصميمك المخصص
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <div
              key={product.id}
              className="group relative bg-dark-light rounded-3xl overflow-hidden border border-white/10 hover:border-gold/50 transition-all duration-500 hover-lift"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Product Image */}
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-light via-transparent to-transparent" />
                
                {/* Price Badge */}
                <div className="absolute top-4 right-4 bg-gold text-dark font-bold px-3 py-1 rounded-lg">
                  {product.price} ر.س
                </div>
              </div>

              {/* Product Info */}
              <div className="p-5">
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-gold transition-colors">
                  {product.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Colors */}
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-xs text-muted-foreground">الألوان:</span>
                  <div className="flex gap-1">
                    {product.colors.slice(0, 4).map((color, i) => (
                      <div
                        key={i}
                        className="w-5 h-5 rounded-full border border-white/20"
                        style={{
                          backgroundColor: 
                            color === 'أسود' ? '#1a1a1a' :
                            color === 'أبيض' ? '#ffffff' :
                            color === 'رمادي' ? '#6b7280' :
                            color === 'أحمر' ? '#ef4444' :
                            color === 'أزرق' ? '#3b82f6' :
                            color === 'أخضر' ? '#22c55e' :
                            color === 'كحلي' ? '#1e3a5f' :
                            color === 'زيتي' ? '#556b2f' :
                            color === 'أصفر' ? '#eab308' :
                            '#888888'
                        }}
                        title={color}
                      />
                    ))}
                    {product.colors.length > 4 && (
                      <span className="text-xs text-muted-foreground">+{product.colors.length - 4}</span>
                    )}
                  </div>
                </div>

                {/* CTA Button */}
                <Button
                  onClick={() => setSelectedProduct(product)}
                  className="w-full bg-white/5 hover:bg-gold hover:text-dark text-white border border-white/10 hover:border-gold transition-all duration-300"
                >
                  اختيار المنتج
                  <ArrowLeft className="w-4 h-4 mr-2" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Product Details Dialog */}
      <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="bg-dark-light border-white/10 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gradient">
              {selectedProduct?.name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedProduct && (
            <div className="space-y-6">
              {/* Product Image */}
              <div className="aspect-video rounded-2xl overflow-hidden">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Description */}
              <p className="text-muted-foreground">{selectedProduct.description}</p>

              {/* Features */}
              <div>
                <h4 className="font-bold text-white mb-3">المميزات:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProduct.features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gold/10 border border-gold/30">
                      <Check className="w-4 h-4 text-gold" />
                      <span className="text-sm text-gold">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Colors */}
              <div>
                <h4 className="font-bold text-white mb-3">الألوان المتاحة:</h4>
                <div className="flex flex-wrap gap-3">
                  {selectedProduct.colors.map((color, i) => (
                    <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-white/10">
                      <div
                        className="w-5 h-5 rounded-full border border-white/20"
                        style={{
                          backgroundColor: 
                            color === 'أسود' ? '#1a1a1a' :
                            color === 'أبيض' ? '#ffffff' :
                            color === 'رمادي' ? '#6b7280' :
                            color === 'أحمر' ? '#ef4444' :
                            color === 'أزرق' ? '#3b82f6' :
                            color === 'أخضر' ? '#22c55e' :
                            color === 'كحلي' ? '#1e3a5f' :
                            color === 'زيتي' ? '#556b2f' :
                            color === 'أصفر' ? '#eab308' :
                            '#888888'
                        }}
                      />
                      <span className="text-sm text-muted-foreground">{color}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div>
                <h4 className="font-bold text-white mb-3">المقاسات:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProduct.sizes.map((size, i) => (
                    <div key={i} className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-muted-foreground">
                      {size}
                    </div>
                  ))}
                </div>
              </div>

              {/* Price & CTA */}
              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <div>
                  <span className="text-muted-foreground text-sm">السعر</span>
                  <div className="text-3xl font-black text-gold">{selectedProduct.price} ر.س</div>
                </div>
                <Button
                  onClick={() => {
                    setSelectedProduct(null);
                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-gold hover:bg-gold-dark text-dark font-bold px-8 py-6 rounded-xl"
                >
                  اطلب الآن
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
