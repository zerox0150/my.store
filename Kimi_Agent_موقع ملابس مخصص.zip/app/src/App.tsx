import Navbar from './components/custom/Navbar';
import Hero from './sections/Hero';
import Products from './sections/Products';
import Models from './sections/Models';
import HowItWorks from './sections/HowItWorks';
import Testimonials from './sections/Testimonials';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-dark text-white overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <Products />
        <Models />
        <HowItWorks />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
